package dev.elementssmp;

/**
 * Every active ability. Each element has three: the first on R, the second on G, the third on C.
 * Cooldowns (seconds) can be overridden in config.yml under "cooldowns".
 */
public enum Ability {
    // Earth
    QUAKE("Quake", 60, Input.R),
    STRENGTH("Strength", 300, Input.G),
    GROUND_BURST("Ground Burst", 180, Input.C),

    // Wind
    WIND_DASH("Wind Dash", 50, Input.R),
    AIR_GUSH("Air Gush", 90, Input.G),
    STORM_VORTEX("Storm Vortex", 180, Input.C),

    // Lightning
    LIGHTNING_STRIKE("Lightning Strike", 45, Input.R),
    THUNDER_BLADE("Thunder Blade", 200, Input.G),
    LIGHTNING_DASH("Dash", 30, Input.C),

    // Fire
    SHACKLES("Shackles", 100, Input.R),
    FIRE_EXPLOSION("Fire Explosion", 300, Input.G),
    FIRE_DOMAIN("Domain", 150, Input.C),

    // Water
    WATER_BLAST("Blast", 80, Input.R),
    WATER_DOMAIN("Domain", 300, Input.G),
    WATER_BLADE("Blade", 80, Input.C),

    // Ice
    FREEZE("Freeze", 60, Input.R),
    FROZEN("Frozen", 300, Input.G),
    METEOR("Meteor", 90, Input.C),

    // Darkness
    SKULK("Skulk", 100, Input.R),
    DRAIN("Drain", 150, Input.G),
    DARKSIDE("Darkside", 150, Input.C);

    /** The three ability keys. */
    public enum Input {
        R("R", 1),
        G("G", 2),
        C("C", 3);

        private final String label;
        private final int slot;
        Input(String label, int slot) { this.label = label; this.slot = slot; }
        public String label() { return label; }
        public int slot() { return slot; }
    }

    private final String display;
    private final int defaultCooldown;
    private final Input input;
    private int cooldown;

    Ability(String display, int cooldown, Input input) {
        this.display = display;
        this.defaultCooldown = cooldown;
        this.cooldown = cooldown;
        this.input = input;
    }

    public String display() { return display; }
    public int cooldown() { return cooldown; }
    public int defaultCooldown() { return defaultCooldown; }
    public Input input() { return input; }
    public void setCooldown(int seconds) { this.cooldown = Math.max(0, seconds); }
}
