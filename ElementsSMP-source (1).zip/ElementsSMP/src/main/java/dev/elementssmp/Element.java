package dev.elementssmp;

import net.kyori.adventure.text.format.NamedTextColor;

import java.util.Locale;

public enum Element {
    EARTH("Earth", NamedTextColor.GREEN,
            Ability.QUAKE, Ability.STRENGTH, Ability.GROUND_BURST),
    WIND("Wind", NamedTextColor.WHITE,
            Ability.WIND_DASH, Ability.AIR_GUSH, Ability.STORM_VORTEX),
    LIGHTNING("Lightning", NamedTextColor.YELLOW,
            Ability.LIGHTNING_STRIKE, Ability.THUNDER_BLADE, Ability.LIGHTNING_DASH),
    FIRE("Fire", NamedTextColor.RED,
            Ability.SHACKLES, Ability.FIRE_EXPLOSION, Ability.FIRE_DOMAIN),
    WATER("Water", NamedTextColor.AQUA,
            Ability.WATER_BLAST, Ability.WATER_DOMAIN, Ability.WATER_BLADE),
    DARKNESS("Darkness", NamedTextColor.DARK_PURPLE,
            Ability.SKULK, Ability.DRAIN, Ability.DARKSIDE),
    ICE("Ice", NamedTextColor.BLUE,
            Ability.FREEZE, Ability.FROZEN, Ability.METEOR);

    private final String display;
    private final NamedTextColor color;
    private final Ability[] abilities;

    Element(String display, NamedTextColor color, Ability... abilities) {
        this.display = display;
        this.color = color;
        this.abilities = abilities;
    }

    public String display() { return display; }
    public NamedTextColor color() { return color; }
    public Ability[] abilities() { return abilities; }

    /** Private-use glyph (U+E000 + ordinal) mapped to this element's icon by the resource pack font. */
    public char icon() { return (char) (0xE000 + ordinal()); }

    /** All three abilities, in key order (R, F, C). */
    public Ability[] selectable() { return abilities; }

    public static Element parse(String s) {
        if (s == null) return null;
        try {
            return valueOf(s.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
