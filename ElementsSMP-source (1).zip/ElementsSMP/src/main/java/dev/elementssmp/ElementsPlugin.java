package dev.elementssmp;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.TileState;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Levelled;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.io.File;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;

public final class ElementsPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter, PluginMessageListener {

    // ---- tuning ----

    // ---- keys ----
    private NamespacedKey elementKey;
    private NamespacedKey bookKey;
    private NamespacedKey modSpeed, modKnockback, modExplosionKb, modMining, modWater;
    private NamespacedKey modStrengthTough, modStrengthKb, modBladeSpeed;
    private NamespacedKey skulkSwordKey, fireballKey, meteorArrowKey;

    // ---- runtime state (not saved; cooldowns reset on restart) ----
    private final Map<UUID, Map<Ability, Long>> cooldowns = new HashMap<>();
    private final Map<UUID, Integer> selected = new HashMap<>();
    private final Map<UUID, Long> lastCombat = new HashMap<>();
    private final Map<UUID, Long> shieldUntil = new HashMap<>();
    private final Set<UUID> flightGranted = new HashSet<>();

    // ---- ability state (not saved) ----
    private enum DomainType { FIRE, WATER, FROZEN, SKULK }

    private static final class Domain {
        final UUID owner;
        final Location center;
        final double radius;
        final long end;
        final DomainType type;
        Domain(UUID owner, Location center, double radius, long end, DomainType type) {
            this.owner = owner; this.center = center; this.radius = radius; this.end = end; this.type = type;
        }
    }

    private static final class Shackle {
        final UUID victim;
        final UUID owner;
        final long end;
        long nextDamage;
        Shackle(UUID victim, UUID owner, long end, long nextDamage) {
            this.victim = victim; this.owner = owner; this.end = end; this.nextDamage = nextDamage;
        }
    }

    private static final class Pit {
        final World world;
        final Location center;
        final int minX, maxX, minZ, maxZ, topY;
        final List<Block> blocks = new ArrayList<>();
        final List<BlockData> data = new ArrayList<>();
        Pit(World world, Location center, int minX, int maxX, int minZ, int maxZ, int topY) {
            this.world = world; this.center = center;
            this.minX = minX; this.maxX = maxX; this.minZ = minZ; this.maxZ = maxZ; this.topY = topY;
        }
    }

    private final Map<UUID, Long> globalCooldownUntil = new HashMap<>();
    private final Map<UUID, Long> frozenUntil = new HashMap<>();
    private final Map<UUID, Long> strengthUntil = new HashMap<>();
    private final Map<UUID, Long> thunderBladeUntil = new HashMap<>();
    private final Map<UUID, Long> waterBladeUntil = new HashMap<>();
    private final Map<UUID, Long> skulkUntil = new HashMap<>();
    private final Map<UUID, Long> darksideUntil = new HashMap<>();
    private final Map<UUID, Long> darksideNextBoom = new HashMap<>();
    private final Map<UUID, Long> meteorArmedUntil = new HashMap<>();
    private final List<Domain> domains = new ArrayList<>();
    private final List<Shackle> shackles = new ArrayList<>();
    private final List<Pit> pits = new ArrayList<>();
    private boolean inAbilityDamage = false;

    // ---- settings (config.yml) ----
    private boolean randomOnJoin = true;
    private boolean avoidRepeat = false;
    private boolean iconsEnabled = true;
    private boolean iconTab = true;
    private boolean iconChat = true;
    private String packUrl = "";
    private String packSha1 = "";
    private boolean packRequired = false;
    private static final String PACK_FILE = "ElementsSMP-Icons-ResourcePack.zip";
    private byte[] packBytes;          // the icon pack bundled inside this jar
    private String embeddedPackSha1;   // its SHA-1, computed at startup
    private HttpServer packServer;     // optional built-in web server for the pack
    private long combatMs = 15_000;
    private int waterShieldSeconds = 8;
    private boolean keyG = true;
    private boolean dropKeyR = true;
    private boolean slot9C = false;
    private boolean shiftSwapThird = true;
    private boolean keyTip = true;
    private boolean castParticles = true;
    private boolean auraParticles = true;
    private int auraCounter = 0;
    private static final String BUILD = "2026-11-06-diagnostics-1";
    private final Set<UUID> debugPlayers = new HashSet<>();
    private int globalCooldownSeconds = 10;
    private boolean fallbackKeys = true;
    private long doubleTapMs = 350;
    private long holdShiftMs = 2000;
    private boolean ctrlDetect = true;
    private int rejoinLockMinutes = 30;
    private boolean resetAssignsRandom = false;
    private boolean menuItemModels = true;
    private Set<String> disabledWorlds = new HashSet<>();
    private boolean floatingIcons = true;
    private float floatingHeight = 0.55f;
    private float floatingScale = 0.6f;
    private boolean showOwnIcon = false;

    // players whose client has the icon resource pack loaded (only they are shown icons)
    private final Set<UUID> packLoaded = ConcurrentHashMap.newKeySet();
    private final Map<UUID, ItemDisplay> floatIcons = new HashMap<>();

    // ---- key tracking (double-tap / hold detection) ----
    private static final String INPUT_CHANNEL = "elementssmp:input";
    private NamespacedKey lastQuitKey;
    private File pendingFile;
    private final Map<Element, Integer> statKills = new EnumMap<>(Element.class);

    // ---- icon cache (chat is async, so it must not read player data directly) ----
    private final Map<UUID, Element> elementCache = new ConcurrentHashMap<>();

    // ---- statistics (saved to stats.yml) ----
    private final Map<Element, Integer> statAssigned = new EnumMap<>(Element.class);
    private final Map<Element, Integer> statUses = new EnumMap<>(Element.class);
    private final Map<UUID, int[]> statPlayer = new HashMap<>(); // [rolls, ability uses]
    private File statsFile;

    @Override
    public void onEnable() {
        elementKey = new NamespacedKey(this, "element");
        bookKey = new NamespacedKey(this, "reroll_book");
        lastQuitKey = new NamespacedKey(this, "last_quit");
        modSpeed = new NamespacedKey(this, "elem_speed");
        modKnockback = new NamespacedKey(this, "elem_knockback");
        modExplosionKb = new NamespacedKey(this, "elem_explosion_kb");
        modMining = new NamespacedKey(this, "elem_mining");
        modWater = new NamespacedKey(this, "elem_water");
        modStrengthTough = new NamespacedKey(this, "elem_strength_tough");
        modStrengthKb = new NamespacedKey(this, "elem_strength_kb");
        modBladeSpeed = new NamespacedKey(this, "elem_blade_speed");
        skulkSwordKey = new NamespacedKey(this, "skulk_sword");
        fireballKey = new NamespacedKey(this, "fire_explosion_ball");
        meteorArrowKey = new NamespacedKey(this, "meteor_arrow");

        saveDefaultConfig();
        loadEmbeddedPack();
        loadSettings();
        getLogger().info("ElementsSMP build " + BUILD + " | keys: F-swap=" + keyG + ", Q-drop=" + dropKeyR
                + ", Shift+F-third=" + shiftSwapThird + ", slot9=" + slot9C + " | global wait=" + globalCooldownSeconds + "s");
        startPackServer();
        if (iconsEnabled && packUrl.isEmpty()) {
            getLogger().warning("icons are enabled but resource-pack.url is empty: players will not be offered the icon pack.");
        }
        pendingFile = new File(getDataFolder(), "pending.yml");
        statsFile = new File(getDataFolder(), "stats.yml");
        loadStats();
        Bukkit.getScheduler().runTaskTimer(this, this::saveStats, 20L * 300, 20L * 300);

        Bukkit.getPluginManager().registerEvents(this, this);
        getServer().getMessenger().registerIncomingPluginChannel(this, INPUT_CHANNEL, this);
        getCommand("element").setExecutor(this);
        getCommand("element").setTabCompleter(this);
        getCommand("ability").setExecutor(this);
        getCommand("ability").setTabCompleter(this);

        // Element Reroll Book (shaped):  W T W / T S T / W T W
        //   W = Nether Wart, T = Totem of Undying, S = Nether Star
        ShapedRecipe recipe = new ShapedRecipe(new NamespacedKey(this, "reroll_book_recipe"), createBook());
        recipe.shape("WTW", "TST", "WTW");
        recipe.setIngredient('W', Material.NETHER_WART);
        recipe.setIngredient('T', Material.TOTEM_OF_UNDYING);
        recipe.setIngredient('S', Material.NETHER_STAR);
        Bukkit.addRecipe(recipe);

        // Keep floating icons attached (teleports, respawns and world changes drop passengers)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!iconsEnabled || !floatingIcons) return;
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.isDead()) continue;
                UUID id = p.getUniqueId();
                Element el = elementCache.get(id);
                ItemDisplay d = floatIcons.get(id);
                if (el == null) {
                    if (d != null) removeFloatingIcon(id);
                } else if (d == null || !d.isValid() || !p.getPassengers().contains(d)) {
                    refreshFloatingIcon(p);
                }
            }
        }, 20L, 20L);

        // Domains, shackles, stuns, timed abilities and the Skulk Sword
        Bukkit.getScheduler().runTaskTimer(this, this::abilityTick, 5L, 5L);

        // Passive refresh (effects, attributes, flight) once a second
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) refreshPassives(p);
        }, 20L, 20L);

        // Action bar + Lightning combat speed + Ice snow speed
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) tickSlow(p);
        }, 10L, 10L);

        // Ice: frost walking and powder snow, needs to be quick
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                Element pe = getElement(p);
                if (pe == Element.ICE) tickIce(p);
                else if (pe == Element.FIRE) tickFire(p);
            }
        }, 2L, 2L);
    }

    @Override
    public void onDisable() {
        if (packServer != null) packServer.stop(0);
        saveStats();
        for (UUID id : new ArrayList<>(floatIcons.keySet())) removeFloatingIcon(id);
        for (Pit pit : new ArrayList<>(pits)) restorePit(pit);
        for (Player p : Bukkit.getOnlinePlayers()) {
            clearModifiers(p);
            removeSkulkSword(p);
            releaseFlight(p);
        }
    }

    // =====================================================================
    //  Element storage
    // =====================================================================

    public Element getElement(Player p) {
        String s = p.getPersistentDataContainer().get(elementKey, PersistentDataType.STRING);
        return Element.parse(s);
    }

    public void setElement(Player p, Element e) {
        cleanupAbilities(p);
        p.getPersistentDataContainer().set(elementKey, PersistentDataType.STRING, e.name());
        elementCache.put(p.getUniqueId(), e);
        statAssigned.merge(e, 1, Integer::sum);
        statPlayer.computeIfAbsent(p.getUniqueId(), k -> new int[2])[0]++;
        selected.put(p.getUniqueId(), 0);
        clearModifiers(p);
        p.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        p.removePotionEffect(PotionEffectType.WATER_BREATHING);
        p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        releaseFlight(p);
        refreshPassives(p);
        updateDisplay(p);
    }

    /** Removes a player's element and everything it granted. */
    public void clearElement(Player p) {
        cleanupAbilities(p);
        p.getPersistentDataContainer().remove(elementKey);
        elementCache.remove(p.getUniqueId());
        selected.remove(p.getUniqueId());
        clearModifiers(p);
        p.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        p.removePotionEffect(PotionEffectType.WATER_BREATHING);
        p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        releaseFlight(p);
        updateDisplay(p);
    }

    private Element randomElement(Element exclude) {
        List<Element> pool = new ArrayList<>(Arrays.asList(Element.values()));
        if (exclude != null) pool.remove(exclude);
        return pool.get(ThreadLocalRandom.current().nextInt(pool.size()));
    }


    // =====================================================================
    //  Settings, icons, statistics
    // =====================================================================

    private void loadSettings() {
        reloadConfig();
        randomOnJoin = getConfig().getBoolean("random-on-join", true);
        avoidRepeat = getConfig().getBoolean("avoid-repeat", false);
        iconsEnabled = getConfig().getBoolean("icons.enabled", true);
        iconTab = getConfig().getBoolean("icons.tab-list", false);
        iconChat = getConfig().getBoolean("icons.chat", true);
        packUrl = getConfig().getString("resource-pack.url", "").trim();
        packSha1 = getConfig().getString("resource-pack.sha1", "").trim();
        packRequired = getConfig().getBoolean("resource-pack.required", false);
        if (getConfig().getBoolean("resource-pack.self-host.enabled", false)) {
            String host = getConfig().getString("resource-pack.self-host.public-address", "").trim();
            int port = getConfig().getInt("resource-pack.self-host.port", 25566);
            if (!host.isEmpty()) packUrl = "http://" + host + ":" + port + "/" + PACK_FILE;
            if (embeddedPackSha1 != null) packSha1 = embeddedPackSha1;
        } else if (packSha1.isEmpty() && embeddedPackSha1 != null) {
            packSha1 = embeddedPackSha1; // the hosted file must be the copy bundled in this plugin
        }
        combatMs = getConfig().getLong("combat-seconds", 15) * 1000L;
        waterShieldSeconds = Math.max(1, getConfig().getInt("water-shield-seconds", 8));
        keyG = getConfig().getBoolean("keys.g-swap-hand", true);
        dropKeyR = getConfig().getBoolean("keys.drop-key-r", true);
        slot9C = getConfig().getBoolean("keys.slot9-c", false);
        shiftSwapThird = getConfig().getBoolean("keys.shift-swap-third", true);
        keyTip = getConfig().getBoolean("keys.show-tip", true);
        castParticles = getConfig().getBoolean("particles.cast-effect", true);
        auraParticles = getConfig().getBoolean("particles.aura", true);
        globalCooldownSeconds = Math.max(0, getConfig().getInt("global-cooldown-seconds", 10));
        rejoinLockMinutes = getConfig().getInt("rejoin-lock-minutes", 30);
        resetAssignsRandom = getConfig().getBoolean("reset-assigns-random", false);
        menuItemModels = getConfig().getBoolean("icons.menu-item-models", true);
        floatingIcons = getConfig().getBoolean("icons.floating", true);
        floatingHeight = (float) getConfig().getDouble("icons.floating-height", 0.55);
        floatingScale = (float) getConfig().getDouble("icons.floating-scale", 0.6);
        showOwnIcon = getConfig().getBoolean("icons.show-own", false);
        disabledWorlds = new HashSet<>(getConfig().getStringList("disabled-worlds"));
        for (Ability a : Ability.values()) {
            a.setCooldown(getConfig().getInt("cooldowns." + a.name().toLowerCase(Locale.ROOT), a.defaultCooldown()));
        }
    }

    /** The element's icon glyph, drawn by the resource pack's elementssmp:icons font. */
    public Component iconComponent(Element e) {
        return Component.text(String.valueOf(e.icon()), NamedTextColor.WHITE)
                .font(Key.key("elementssmp", "icons"))
                .decoration(TextDecoration.BOLD, false)
                .decoration(TextDecoration.ITALIC, false);
    }

    private Component elementLabel(Element e) {
        return Component.text(e.display(), e.color(), TextDecoration.BOLD);
    }

    private void updateDisplay(Player p) {
        refreshFloatingIcon(p);
        Element e = getElement(p);
        if (e == null || !iconsEnabled || !iconTab) {
            p.playerListName(null);
            return;
        }
        // The icon must be a SIBLING of the name, not its parent: children inherit the parent's font,
        // and the icon font only contains the seven element icons (the name would turn into boxes).
        p.playerListName(Component.empty()
                .append(iconComponent(e))
                .append(Component.space())
                .append(Component.text(p.getName(), e.color()).font(Key.key("minecraft", "default"))));
    }

    /** Reads the icon pack bundled in the jar, computes its SHA-1 and copies it to the plugin folder. */
    private void loadEmbeddedPack() {
        try (InputStream in = getResource(PACK_FILE)) {
            if (in == null) {
                getLogger().warning("The icon resource pack is missing from the plugin jar.");
                return;
            }
            packBytes = in.readAllBytes();
            StringBuilder hex = new StringBuilder();
            for (byte b : MessageDigest.getInstance("SHA-1").digest(packBytes)) {
                hex.append(String.format("%02x", b));
            }
            embeddedPackSha1 = hex.toString();
            getDataFolder().mkdirs();
            Files.write(new File(getDataFolder(), PACK_FILE).toPath(), packBytes);
        } catch (Exception ex) {
            getLogger().warning("Could not read the bundled icon pack: " + ex.getMessage());
        }
    }

    /** Optional: serve the bundled pack from this plugin (only useful if the host opens a second port). */
    private void startPackServer() {
        if (packBytes == null || !getConfig().getBoolean("resource-pack.self-host.enabled", false)) return;
        int port = getConfig().getInt("resource-pack.self-host.port", 25566);
        if (getConfig().getString("resource-pack.self-host.public-address", "").trim().isEmpty()) {
            getLogger().warning("resource-pack.self-host is on but public-address is empty: players won't get the pack.");
        }
        try {
            packServer = HttpServer.create(new InetSocketAddress(port), 0);
            packServer.createContext("/" + PACK_FILE, ex -> {
                ex.getResponseHeaders().add("Content-Type", "application/zip");
                ex.sendResponseHeaders(200, packBytes.length);
                try (OutputStream os = ex.getResponseBody()) {
                    os.write(packBytes);
                }
            });
            packServer.start();
            getLogger().info("Serving the icon pack on port " + port);
        } catch (IOException ex) {
            getLogger().warning("Could not start the built-in pack server on port " + port + ": " + ex.getMessage());
        }
    }

    private void sendPack(Player p) {
        if (!iconsEnabled || packUrl.isEmpty()) return;
        byte[] hash = null;
        if (packSha1.length() == 40) {
            try {
                hash = new byte[20];
                for (int i = 0; i < 20; i++) {
                    hash[i] = (byte) Integer.parseInt(packSha1.substring(i * 2, i * 2 + 2), 16);
                }
            } catch (NumberFormatException ex) {
                hash = null;
            }
        }
        UUID packId = UUID.nameUUIDFromBytes(packUrl.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        p.setResourcePack(packId, packUrl, hash,
                Component.text("ElementsSMP element icons"), packRequired);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (!iconsEnabled || !iconChat) return;
        Element el = elementCache.get(e.getPlayer().getUniqueId());
        if (el == null) return;
        // The icon is only added for viewers who have the resource pack, so nobody sees boxes.
        e.renderer((source, name, message, viewer) -> {
            Component who = name;
            if (viewer instanceof Player v && packLoaded.contains(v.getUniqueId())) {
                who = Component.empty().append(iconComponent(el)).append(Component.space()).append(name);
            }
            return Component.translatable("chat.type.text", who, message);
        });
    }

    // =====================================================================
    //  Floating icon above each player's head
    // =====================================================================

    private void removeFloatingIcon(UUID id) {
        ItemDisplay d = floatIcons.remove(id);
        if (d != null && d.isValid()) d.remove();
    }

    private void refreshFloatingIcon(Player p) {
        removeFloatingIcon(p.getUniqueId());
        if (!iconsEnabled || !floatingIcons || p.isDead() || !p.isOnline()) return;
        Element el = getElement(p);
        if (el == null) return;
        NamespacedKey model = NamespacedKey.fromString("elementssmp:" + el.name().toLowerCase(Locale.ROOT));
        if (model == null) return;

        ItemDisplay d = p.getWorld().spawn(p.getLocation(), ItemDisplay.class, disp -> {
            ItemStack item = new ItemStack(Material.PAPER);
            ItemMeta meta = item.getItemMeta();
            meta.setItemModel(model);
            item.setItemMeta(meta);
            disp.setItemStack(item);
            disp.setBillboard(Display.Billboard.CENTER);
            disp.setTransformation(new Transformation(
                    new Vector3f(0f, floatingHeight, 0f), new AxisAngle4f(),
                    new Vector3f(floatingScale, floatingScale, floatingScale), new AxisAngle4f()));
            disp.setPersistent(false);
            disp.setVisibleByDefault(false); // hidden until a viewer has the resource pack
        });
        p.addPassenger(d);
        floatIcons.put(p.getUniqueId(), d);
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (packLoaded.contains(viewer.getUniqueId()) && (showOwnIcon || !viewer.equals(p))) {
                viewer.showEntity(this, d);
            }
        }
    }

    @EventHandler
    public void onPackStatus(PlayerResourcePackStatusEvent e) {
        Player viewer = e.getPlayer();
        UUID id = viewer.getUniqueId();
        if (e.getStatus() == PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED) {
            packLoaded.add(id);
            for (Map.Entry<UUID, ItemDisplay> en : floatIcons.entrySet()) {
                ItemDisplay d = en.getValue();
                if (d.isValid() && (showOwnIcon || !en.getKey().equals(id))) viewer.showEntity(this, d);
            }
        } else if (e.getStatus() != PlayerResourcePackStatusEvent.Status.ACCEPTED
                && e.getStatus() != PlayerResourcePackStatusEvent.Status.DOWNLOADED) {
            packLoaded.remove(id);
            for (ItemDisplay d : floatIcons.values()) {
                if (d.isValid()) viewer.hideEntity(this, d);
            }
        }
    }

    private void loadStats() {
        if (!statsFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(statsFile);
        for (Element e : Element.values()) {
            statAssigned.put(e, y.getInt("assigned." + e.name(), 0));
            statUses.put(e, y.getInt("uses." + e.name(), 0));
            statKills.put(e, y.getInt("kills." + e.name(), 0));
        }
        if (y.getConfigurationSection("players") != null) {
            for (String key : y.getConfigurationSection("players").getKeys(false)) {
                try {
                    statPlayer.put(UUID.fromString(key), new int[]{
                            y.getInt("players." + key + ".rolls", 0),
                            y.getInt("players." + key + ".uses", 0)});
                } catch (IllegalArgumentException ignored) { }
            }
        }
    }

    private void saveStats() {
        if (statsFile == null) return;
        YamlConfiguration y = new YamlConfiguration();
        for (Element e : Element.values()) {
            y.set("assigned." + e.name(), statAssigned.getOrDefault(e, 0));
            y.set("uses." + e.name(), statUses.getOrDefault(e, 0));
            y.set("kills." + e.name(), statKills.getOrDefault(e, 0));
        }
        for (Map.Entry<UUID, int[]> en : statPlayer.entrySet()) {
            y.set("players." + en.getKey() + ".rolls", en.getValue()[0]);
            y.set("players." + en.getKey() + ".uses", en.getValue()[1]);
        }
        try {
            getDataFolder().mkdirs();
            y.save(statsFile);
        } catch (IOException ex) {
            getLogger().warning("Could not save stats.yml: " + ex.getMessage());
        }
    }

    // =====================================================================
    //  Offline players (queued until their next login)
    // =====================================================================

    private void queuePending(UUID id, String action) {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(pendingFile);
        y.set("pending." + id, action);
        try {
            getDataFolder().mkdirs();
            y.save(pendingFile);
        } catch (IOException ex) {
            getLogger().warning("Could not save pending.yml: " + ex.getMessage());
        }
    }

    /** Queues an action for a known offline player. Returns false if no such player has joined before. */
    private boolean queueOffline(CommandSender sender, String name, String action) {
        OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(name);
        if (off == null || !off.hasPlayedBefore()) return false;
        queuePending(off.getUniqueId(), action);
        sender.sendMessage(Component.text(name + " is offline. This will apply when they next join.", NamedTextColor.YELLOW));
        return true;
    }

    private boolean applyPending(Player p) {
        if (pendingFile == null || !pendingFile.exists()) return false;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(pendingFile);
        String key = "pending." + p.getUniqueId();
        String action = y.getString(key);
        if (action == null) return false;
        y.set(key, null);
        try {
            y.save(pendingFile);
        } catch (IOException ex) {
            getLogger().warning("Could not save pending.yml: " + ex.getMessage());
        }
        Element result = null;
        if (action.startsWith("SET:")) {
            result = Element.parse(action.substring(4));
        } else if (action.equals("GIVE")) {
            result = randomElement(getElement(p));
        } else if (action.equals("RESET")) {
            clearElement(p);
            if (resetAssignsRandom) result = randomElement(null);
            else {
                p.sendMessage(Component.text("Your element was reset.", NamedTextColor.GRAY));
                return true;
            }
        }
        if (result == null) return false;
        setElement(p, result);
        p.sendMessage(Component.text("An admin gave you the ", NamedTextColor.GRAY)
                .append(elementLabel(result)).append(Component.text(" element!", NamedTextColor.GRAY)));
        return true;
    }

    // =====================================================================
    //  Key input: R = first ability, G = second ability, C = third ability
    // =====================================================================

    private void dbg(Player p, String msg) {
        if (debugPlayers.contains(p.getUniqueId())) {
            p.sendMessage(Component.text("[debug] " + msg, NamedTextColor.DARK_GRAY));
        }
    }

    /** Explains which keys fire the three abilities with the current settings. */
    private void sendKeyHelp(Player p) {
        StringBuilder sb = new StringBuilder("Ability keys: ");
        sb.append(dropKeyR ? "Q (or R if rebound to Drop) = 1st, " : "/ability 1 = 1st, ");
        sb.append(keyG ? "F (or G if rebound to Swap Hands) = 2nd, " : "/ability 2 = 2nd, ");
        if (shiftSwapThird && keyG) sb.append("Shift+F (or Shift+G) = 3rd");
        else if (slot9C) sb.append("9 (or C if rebound to Hotbar 9) = 3rd");
        else sb.append("/ability 3 = 3rd");
        p.sendMessage(Component.text(sb.toString(), NamedTextColor.GRAY));
        if (dropKeyR) {
            p.sendMessage(Component.text("Hold Shift while pressing Q to drop an item normally.", NamedTextColor.DARK_GRAY));
        }
    }

    /** Fires this element's ability on the given slot (1 = R, 2 = G, 3 = C). */
    private void trigger(Player p, int slot) {
        Element el = getElement(p);
        if (el == null) {
            dbg(p, "key pressed but you have no element");
            return;
        }
        for (Ability a : el.abilities()) {
            if (a.input().slot() == slot) {
                dbg(p, "key slot " + slot + " -> " + a.display());
                use(p, a);
                return;
            }
        }
    }

    /**
     * G = second ability. Minecraft has no G action, so players rebind "Swap Item With Offhand"
     * to G in Options > Controls; this event then fires whenever they press it.
     */
    @EventHandler
    public void onSwapHand(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        dbg(p, "swap-hands key detected (element=" + getElement(p) + ", sneaking=" + p.isSneaking() + ", enabled=" + keyG + ")");
        if (!keyG) return;
        if (getElement(p) == null) return;
        e.setCancelled(true);
        trigger(p, shiftSwapThird && p.isSneaking() ? 3 : 2);
    }

    /**
     * Optional: the drop key triggers the first ability (rebind "Drop Selected Item" to R in
     * Controls). Shift + drop still drops normally. The Skulk Sword can never be dropped.
     */
    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        dbg(p, "drop key detected (Q-mode=" + dropKeyR + ", sneaking=" + p.isSneaking() + ")");
        if (isSkulkSword(e.getItemDrop().getItemStack())) {
            e.setCancelled(true);
            return;
        }
        if (!dropKeyR || p.isSneaking() || getElement(p) == null) return;
        e.setCancelled(true);
        trigger(p, 1);
    }

    /** Optional: selecting hotbar slot 9 triggers the third ability (rebind "Hotbar Slot 9" to C in Controls). */
    @EventHandler
    public void onHeld(PlayerItemHeldEvent e) {
        if (!slot9C || e.getNewSlot() != 8 || getElement(e.getPlayer()) == null) return;
        e.setCancelled(true);
        trigger(e.getPlayer(), 3);
    }

    /**
     * R, G and C are not keys a server plugin can see on its own. A companion client mod can send
     * them on the "elementssmp:input" plugin channel as plain text: R, G or C. Cooldowns still apply.
     */
    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (!INPUT_CHANNEL.equals(channel)) return;
        String text = new String(message, java.nio.charset.StandardCharsets.UTF_8)
                .replaceAll("[^A-Za-z]", "").toUpperCase(Locale.ROOT);
        switch (text) {
            case "R" -> trigger(player, 1);
            case "G" -> trigger(player, 2);
            case "C" -> trigger(player, 3);
            default -> { }
        }
    }

    // =====================================================================
    //  Kills + element menu
    // =====================================================================

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(this::isSkulkSword);
        cleanupAbilities(e.getEntity());
        Player killer = e.getEntity().getKiller();
        if (killer == null) return;
        Element el = getElement(killer);
        if (el != null) statKills.merge(el, 1, Integer::sum);
    }

    private static final class MenuHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() { return null; }
    }

    private static final Material[] MENU_ICONS = {
            Material.GRASS_BLOCK, Material.FEATHER, Material.LIGHTNING_ROD, Material.BLAZE_POWDER,
            Material.WATER_BUCKET, Material.ECHO_SHARD, Material.BLUE_ICE};

    private void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(new MenuHolder(), 9, Component.text("Elements"));
        Element mine = getElement(p);
        Element[] all = Element.values();
        for (int i = 0; i < all.length; i++) {
            Element el = all[i];
            ItemStack item = new ItemStack(MENU_ICONS[i]);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text(el.display(), el.color(), TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            List<Component> lore = new ArrayList<>();
            if (el == mine) {
                lore.add(Component.text("Your element", NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false));
            }
            for (Ability a : el.abilities()) {
                lore.add(Component.text(a.display() + " (" + a.cooldown() + "s) - " + a.input().label(),
                        NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            }
            meta.lore(lore);
            meta.setEnchantmentGlintOverride(el == mine);
            if (menuItemModels && iconsEnabled) {
                NamespacedKey model = NamespacedKey.fromString("elementssmp:" + el.name().toLowerCase(Locale.ROOT));
                if (model != null) meta.setItemModel(model);
            }
            item.setItemMeta(meta);
            inv.setItem(1 + i, item);
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onMenuDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder) e.setCancelled(true);
    }

    // =====================================================================
    //  Reroll book
    // =====================================================================

    private ItemStack createBook() {
        ItemStack item = new ItemStack(Material.BOOK);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Element Reroll Book", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Right-click to replace your element", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("with a new random one.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(bookKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isBook(ItemStack item) {
        if (item == null || item.getType() != Material.BOOK || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(bookKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (!isBook(item)) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        Element old = getElement(p);
        Element next = randomElement(old);
        item.setAmount(item.getAmount() - 1);
        setElement(p, next);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 40, 0.5, 0.8, 0.5, 0.05);
        p.sendMessage(Component.text("Your element is now ", NamedTextColor.GRAY)
                .append(elementLabel(next)));
    }

    // =====================================================================
    //  Join / quit / respawn
    // =====================================================================

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        sendPack(p);
        if (keyTip) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (p.isOnline() && getElement(p) != null) sendKeyHelp(p);
            }, 80L);
        }
        if (applyPending(p)) return;

        Element old = getElement(p);
        boolean locked = false;
        if (old != null && randomOnJoin && rejoinLockMinutes > 0) {
            Long quit = p.getPersistentDataContainer().get(lastQuitKey, PersistentDataType.LONG);
            locked = quit != null && System.currentTimeMillis() - quit < rejoinLockMinutes * 60_000L;
        }
        if (old == null || (randomOnJoin && !locked)) {
            Element next = randomElement(avoidRepeat ? old : null);
            setElement(p, next);
            p.sendMessage(Component.text("You were given the ", NamedTextColor.GRAY)
                    .append(elementLabel(next))
                    .append(Component.text(" element! Use /element info to see your abilities.", NamedTextColor.GRAY)));
        } else {
            elementCache.put(p.getUniqueId(), old);
            refreshPassives(p);
            updateDisplay(p);
            if (locked) {
                p.sendMessage(Component.text("You rejoined quickly, so you keep your ", NamedTextColor.GRAY)
                        .append(elementLabel(old)).append(Component.text(" element.", NamedTextColor.GRAY)));
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        clearModifiers(p);
        releaseFlight(p);
        UUID id = p.getUniqueId();
        removeFloatingIcon(id);
        packLoaded.remove(id);
        p.getPersistentDataContainer().set(lastQuitKey, PersistentDataType.LONG, System.currentTimeMillis());
        cleanupAbilities(p);
        globalCooldownUntil.remove(id);
        elementCache.remove(id);
        selected.remove(id);
        lastCombat.remove(id);
        shieldUntil.remove(id);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Bukkit.getScheduler().runTaskLater(this, () -> refreshPassives(e.getPlayer()), 2L);
    }

    // =====================================================================
    //  Passives
    // =====================================================================

    private void clearModifiers(Player p) {
        removeMod(p, Attribute.MOVEMENT_SPEED, modSpeed);
        removeMod(p, Attribute.KNOCKBACK_RESISTANCE, modKnockback);
        removeMod(p, Attribute.EXPLOSION_KNOCKBACK_RESISTANCE, modExplosionKb);
        removeMod(p, Attribute.MINING_EFFICIENCY, modMining);
        removeMod(p, Attribute.WATER_MOVEMENT_EFFICIENCY, modWater);
        removeMod(p, Attribute.ARMOR_TOUGHNESS, modStrengthTough);
        removeMod(p, Attribute.KNOCKBACK_RESISTANCE, modStrengthKb);
        removeMod(p, Attribute.ATTACK_SPEED, modBladeSpeed);
    }

    private void removeMod(Player p, Attribute attr, NamespacedKey key) {
        AttributeInstance inst = p.getAttribute(attr);
        if (inst == null) return;
        AttributeModifier m = inst.getModifier(key);
        if (m != null) inst.removeModifier(m);
    }

    private void setMod(Player p, Attribute attr, NamespacedKey key, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(attr);
        if (inst == null) return;
        AttributeModifier existing = inst.getModifier(key);
        if (existing != null) {
            if (existing.getAmount() == amount && existing.getOperation() == op) return;
            inst.removeModifier(existing);
        }
        inst.addModifier(new AttributeModifier(key, amount, op, EquipmentSlotGroup.ANY));
    }

    private void refreshPassives(Player p) {
        Element e = getElement(p);
        if (e == null || p.isDead()) return;

        // Remove modifiers that don't belong to this element, then add the ones that do.
        if (e != Element.WIND) removeMod(p, Attribute.MOVEMENT_SPEED, modSpeed);
        if (e != Element.EARTH) {
            removeMod(p, Attribute.KNOCKBACK_RESISTANCE, modKnockback);
            removeMod(p, Attribute.EXPLOSION_KNOCKBACK_RESISTANCE, modExplosionKb);
            removeMod(p, Attribute.MINING_EFFICIENCY, modMining);
        }
        if (e != Element.WATER) removeMod(p, Attribute.WATER_MOVEMENT_EFFICIENCY, modWater);

        switch (e) {
            case EARTH -> {
                setMod(p, Attribute.KNOCKBACK_RESISTANCE, modKnockback, 0.5, AttributeModifier.Operation.ADD_NUMBER);
                setMod(p, Attribute.EXPLOSION_KNOCKBACK_RESISTANCE, modExplosionKb, 0.5, AttributeModifier.Operation.ADD_NUMBER);
                setMod(p, Attribute.MINING_EFFICIENCY, modMining, 4.0, AttributeModifier.Operation.ADD_NUMBER);
            }
            case WIND -> setMod(p, Attribute.MOVEMENT_SPEED, modSpeed, 0.2, AttributeModifier.Operation.ADD_SCALAR);
            case FIRE -> p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 100, 0, true, false, false));
            case WATER -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, 100, 0, true, false, false));
                setMod(p, Attribute.WATER_MOVEMENT_EFFICIENCY, modWater, 1.0, AttributeModifier.Operation.ADD_NUMBER);
            }
            case DARKNESS -> p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 400, 0, true, false, false));
            default -> { }
        }

        releaseFlight(p); // older versions granted flight for Double Jump; make sure it is cleaned up
    }

    private void releaseFlight(Player p) {
        if (flightGranted.remove(p.getUniqueId())) {
            if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) {
                p.setFlying(false);
                p.setAllowFlight(false);
            }
        }
    }

    /** Runs every 10 ticks per player: action bar and light passives. */
    private void tickSlow(Player p) {
        Element e = getElement(p);
        if (e == null || p.isDead()) return;

        if (e == Element.LIGHTNING && inCombat(p)) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, 1, true, false, false));
        }
        if (e == Element.ICE) {
            Block feet = p.getLocation().getBlock();
            Block below = feet.getRelative(BlockFace.DOWN);
            if (isSnow(feet.getType()) || isSnow(below.getType())) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, 1, true, false, false));
            }
        }
        sendBar(p, e);
    }

    private boolean isSnow(Material m) {
        return m == Material.SNOW || m == Material.SNOW_BLOCK || m == Material.POWDER_SNOW;
    }

    private void tickIce(Player p) {
        // Don't sink into powdered snow (approximation: gently lift the player and clear freezing).
        if (p.getLocation().getBlock().getType() == Material.POWDER_SNOW) {
            Vector v = p.getVelocity();
            if (v.getY() < 0.15) p.setVelocity(v.setY(0.15));
            p.setFreezeTicks(0);
        }
        // Freeze water beneath the player's feet (radius 2), reverting after a few seconds.
        Location l = p.getLocation();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx * dx + dz * dz > 4) continue;
                Block b = l.getWorld().getBlockAt(l.getBlockX() + dx, l.getBlockY() - 1, l.getBlockZ() + dz);
                if (b.getType() != Material.WATER) continue;
                if (!(b.getBlockData() instanceof Levelled lv) || lv.getLevel() != 0) continue;
                if (!b.getRelative(BlockFace.UP).getType().isAir()) continue;
                b.setType(Material.FROSTED_ICE, false);
                long delay = 60 + ThreadLocalRandom.current().nextInt(40);
                Bukkit.getScheduler().runTaskLater(this, () -> {
                    if (b.getType() == Material.FROSTED_ICE) b.setType(Material.WATER, false);
                }, delay);
            }
        }
    }

    private void sendBar(Player p, Element e) {
        long now = System.currentTimeMillis();
        Map<Ability, Long> cd = cooldowns.getOrDefault(p.getUniqueId(), Map.of());
        Component line = Component.text(e.display() + "  ", e.color(), TextDecoration.BOLD);
        for (Ability a : e.abilities()) {
            long until = cd.getOrDefault(a, 0L);
            boolean ready = until <= now;
            String label = a.input().label() + ": " + a.display() + (ready ? "" : " " + ((until - now + 999) / 1000) + "s");
            line = line.append(Component.text(label + "  ", ready ? NamedTextColor.GREEN : NamedTextColor.RED));
        }
        long g = globalCooldownUntil.getOrDefault(p.getUniqueId(), 0L);
        if (g > now) {
            line = line.append(Component.text("(wait " + ((g - now + 999) / 1000) + "s)", NamedTextColor.GRAY));
        }
        p.sendActionBar(line);
    }

    // =====================================================================
    //  Damage passives
    // =====================================================================

    private boolean inCombat(Player p) {
        return System.currentTimeMillis() - lastCombat.getOrDefault(p.getUniqueId(), 0L) < combatMs;
    }

    private boolean isNight(World w) {
        if (w.getEnvironment() != World.Environment.NORMAL) return false;
        long t = w.getTime();
        return t >= 13000 && t <= 23000;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (disabledWorlds.contains(e.getEntity().getWorld().getName())) return;
        DamageCause cause = e.getCause();
        Player attacker = null;
        if (e instanceof EntityDamageByEntityEvent be) {
            Entity d = be.getDamager();
            if (d instanceof Player pl) attacker = pl;
            else if (d instanceof Projectile pr && pr.getShooter() instanceof Player sp) attacker = sp;
        }
        double mult = 1.0;

        // ---- victim passives ----
        if (e.getEntity() instanceof Player victim) {
            Element ve = getElement(victim);
            if (ve != null) {
                switch (ve) {
                    case FIRE -> {
                        if (cause == DamageCause.FIRE || cause == DamageCause.FIRE_TICK
                                || cause == DamageCause.LAVA || cause.name().equals("CAMPFIRE")) {
                            e.setCancelled(true);
                            victim.setFireTicks(0);
                            return;
                        }
                    }
                    case EARTH -> {
                        switch (cause) {
                            case ENTITY_ATTACK, ENTITY_SWEEP_ATTACK, PROJECTILE, FALL, CONTACT, FALLING_BLOCK,
                                 FLY_INTO_WALL -> mult *= 0.85;
                            case BLOCK_EXPLOSION, ENTITY_EXPLOSION -> mult *= 0.6;
                            default -> { }
                        }
                    }
                    case WIND -> {
                        if (cause == DamageCause.FALL) mult *= 0.3;
                    }
                    case DARKNESS -> {
                        if (attacker != null && isNight(victim.getWorld())) mult *= 0.8;
                    }
                    case WATER -> {
                        if (shieldUntil.getOrDefault(victim.getUniqueId(), 0L) > System.currentTimeMillis()) mult *= 0.6;
                    }
                    default -> { }
                }
            }
        }

        // ---- attacker passives ----
        if (attacker != null && !inAbilityDamage && e.getEntity() instanceof LivingEntity victimLiving) {
            boolean pvp = victimLiving instanceof Player;
            if (pvp) {
                long now = System.currentTimeMillis();
                lastCombat.put(attacker.getUniqueId(), now);
                lastCombat.put(victimLiving.getUniqueId(), now);
            }
            Element ae = getElement(attacker);
            if (ae != null) {
                switch (ae) {
                    case LIGHTNING -> {
                        if (pvp && attacker.getWorld().hasStorm()) mult *= 1.25;
                    }
                    case FIRE -> {
                        ItemStack hand = attacker.getInventory().getItemInMainHand();
                        if (hand.getType() != Material.AIR && hand.containsEnchantment(Enchantment.FIRE_ASPECT)) mult *= 1.25;
                    }
                    case WATER -> {
                        if (attacker.isInWater()) mult *= 1.25;
                    }
                    case DARKNESS -> {
                        if (pvp && isNight(attacker.getWorld())) mult *= 1.2;
                    }
                    case ICE -> {
                        boolean melee = e instanceof EntityDamageByEntityEvent be2 && be2.getDamager().equals(attacker);
                        boolean crit = melee && attacker.getFallDistance() > 0 && !attacker.isOnGround()
                                && !attacker.isClimbing() && !attacker.isInWater() && !attacker.isSprinting();
                        if (crit) {
                            victimLiving.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 6, false, false, false));
                            victimLiving.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 40, 128, false, false, false));
                            victimLiving.setFreezeTicks(victimLiving.getMaxFreezeTicks());
                            victimLiving.getWorld().spawnParticle(Particle.SNOWFLAKE,
                                    victimLiving.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.02);
                        }
                    }
                    default -> { }
                }
            }
        }

        if (mult != 1.0) e.setDamage(e.getDamage() * mult);
    }

    // =====================================================================
    //  Using abilities
    // =====================================================================

    /** Reads a tunable from config.yml (abilities.*). */
    private double num(String key, double def) {
        return getConfig().getDouble("abilities." + key, def);
    }

    private void use(Player p, Ability a) {
        Element el = getElement(p);
        if (el == null || !Arrays.asList(el.abilities()).contains(a)) {
            dbg(p, "ability " + a.display() + " is not one of your abilities");
            return;
        }
        if (disabledWorlds.contains(p.getWorld().getName())) {
            p.sendActionBar(Component.text("Abilities are disabled in this world", NamedTextColor.RED));
            return;
        }
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        if (frozenUntil.getOrDefault(id, 0L) > now) {
            p.sendActionBar(Component.text("You are stunned!", NamedTextColor.RED));
            return;
        }
        long global = globalCooldownUntil.getOrDefault(id, 0L);
        if (global > now) {
            p.sendActionBar(Component.text("Ability cooldown: wait " + ((global - now + 999) / 1000)
                    + "s before using another ability", NamedTextColor.RED));
            return;
        }
        Map<Ability, Long> cd = cooldowns.computeIfAbsent(id, k -> new EnumMap<>(Ability.class));
        long until = cd.getOrDefault(a, 0L);
        if (until > now) {
            p.sendActionBar(Component.text(a.display() + " ready in " + ((until - now + 999) / 1000) + "s", NamedTextColor.RED));
            return;
        }
        if (!execute(p, a)) {
            dbg(p, a.display() + " could not fire (needs a target in sight, diamond armor, or a free inventory slot)");
            return;
        }
        dbg(p, a.display() + " fired");
        if (castParticles) castEffect(p, el);
        cd.put(a, now + a.cooldown() * 1000L);
        if (globalCooldownSeconds > 0) {
            globalCooldownUntil.put(id, now + globalCooldownSeconds * 1000L);
        }
        statUses.merge(el, 1, Integer::sum);
        statPlayer.computeIfAbsent(id, k -> new int[2])[1]++;
    }

    private void noTarget(Player p) {
        p.sendActionBar(Component.text("No target in sight", NamedTextColor.RED));
    }

    /** Returns true if the ability fired (and the cooldowns should start). */
    private boolean execute(Player p, Ability a) {
        World w = p.getWorld();
        Location loc = p.getLocation();
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        switch (a) {

            // ------------------------------------------------------------- EARTH
            case QUAKE -> {
                int stunTicks = (int) (num("quake.stun-seconds", 3) * 20);
                int slowTicks = (int) (num("quake.slowness-seconds", 30) * 20);
                w.spawnParticle(Particle.BLOCK, loc, 150, 3, 0.2, 3, Material.DIRT.createBlockData());
                w.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.6f);
                for (LivingEntity t : nearbyLiving(loc, num("quake.radius", 6), p)) {
                    freezeEntity(t, stunTicks);
                    int remaining = slowTicks - stunTicks;
                    if (remaining > 0) {
                        Bukkit.getScheduler().runTaskLater(this, () -> {
                            if (t.isValid()) {
                                t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, remaining, 1, false, true, true));
                            }
                        }, stunTicks);
                    }
                }
                return true;
            }
            case STRENGTH -> {
                int pieces = 0;
                for (ItemStack it : p.getInventory().getArmorContents()) {
                    if (it == null) continue;
                    switch (it.getType()) {
                        case DIAMOND_HELMET, DIAMOND_CHESTPLATE, DIAMOND_LEGGINGS, DIAMOND_BOOTS -> pieces++;
                        default -> { }
                    }
                }
                if (pieces == 0) {
                    p.sendActionBar(Component.text("Wear diamond armor to use Strength", NamedTextColor.RED));
                    return false;
                }
                // Netherite armor gives +1 toughness and +0.1 knockback resistance per piece over diamond.
                setMod(p, Attribute.ARMOR_TOUGHNESS, modStrengthTough, pieces * 1.0, AttributeModifier.Operation.ADD_NUMBER);
                setMod(p, Attribute.KNOCKBACK_RESISTANCE, modStrengthKb, pieces * 0.1, AttributeModifier.Operation.ADD_NUMBER);
                strengthUntil.put(id, now + (long) (num("strength.seconds", 90) * 1000));
                w.spawnParticle(Particle.ENCHANT, loc.clone().add(0, 1, 0), 80, 0.6, 1, 0.6, 0.5);
                w.playSound(loc, Sound.BLOCK_BEACON_POWER_SELECT, 1f, 0.8f);
                p.sendActionBar(Component.text("Your armor is now netherite-grade", NamedTextColor.GREEN));
                return true;
            }
            case GROUND_BURST -> {
                LivingEntity t = target(p, num("ground-burst.range", 25));
                if (t == null) {
                    noTarget(p);
                    return false;
                }
                // crack line from the caster to the target
                Vector dir = t.getLocation().toVector().subtract(loc.toVector());
                double dist = dir.length();
                if (dist > 0.1) {
                    dir.normalize();
                    for (double d = 1; d < dist; d += 0.8) {
                        Location at = loc.clone().add(dir.clone().multiply(d));
                        w.spawnParticle(Particle.BLOCK, at.add(0, 0.2, 0), 6, 0.2, 0.1, 0.2, Material.STONE.createBlockData());
                    }
                }
                w.playSound(t.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.5f);
                createPit(t.getLocation(), (int) num("ground-burst.depth", 4), (int) (num("ground-burst.pit-seconds", 8) * 20));
                return true;
            }

            // ------------------------------------------------------------- WIND
            case WIND_DASH -> {
                Vector d = loc.getDirection().setY(0.15).normalize().multiply(num("wind-dash.power", 2.2));
                p.setVelocity(d);
                p.setFallDistance(0f);
                w.spawnParticle(Particle.CLOUD, loc.clone().add(0, 1, 0), 60, 0.8, 0.5, 0.8, 0.1);
                w.playSound(loc, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.6f);
                return true;
            }
            case AIR_GUSH -> {
                LivingEntity t = target(p, num("air-gush.range", 10));
                if (t == null) {
                    noTarget(p);
                    return false;
                }
                t.setVelocity(new Vector(0, num("air-gush.launch-velocity", 3.2), 0));
                w.spawnParticle(Particle.CLOUD, t.getLocation(), 80, 0.4, 0.2, 0.4, 0.2);
                w.playSound(t.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1f, 0.6f);
                return true;
            }
            case STORM_VORTEX -> {
                double r = num("storm-vortex.radius", 5);
                double force = num("storm-vortex.force", 2.8);
                ring(loc, r, Particle.CLOUD, 40, 0.3);
                ring(loc, r * 0.6, Particle.CLOUD, 24, 1.0);
                w.playSound(loc, Sound.ENTITY_PHANTOM_FLAP, 1.2f, 0.6f);
                for (Entity t : nearbyAll(loc, r, p)) push(p, t, force, 0.7);
                return true;
            }

            // ------------------------------------------------------------- LIGHTNING
            case LIGHTNING_STRIKE -> {
                LivingEntity t = target(p, num("lightning-strike.range", 30));
                if (t == null) {
                    noTarget(p);
                    return false;
                }
                w.strikeLightningEffect(t.getLocation());
                abilityDamage(t, num("lightning-strike.damage", 10.0), p); // 5 hearts
                return true;
            }
            case THUNDER_BLADE -> {
                thunderBladeUntil.put(id, now + (long) (num("thunder-blade.seconds", 40) * 1000));
                w.spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0, 1, 0), 80, 0.5, 0.9, 0.5, 0.3);
                w.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 1.6f);
                p.sendActionBar(Component.text("Thunder Blade active: critical hits call lightning", NamedTextColor.YELLOW));
                return true;
            }
            case LIGHTNING_DASH -> {
                Vector d = loc.getDirection().setY(0.1).normalize().multiply(num("lightning-dash.power", 2.4));
                p.setVelocity(d);
                p.setFallDistance(0f);
                w.spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0, 1, 0), 60, 0.5, 0.8, 0.5, 0.3);
                w.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 2f);
                return true;
            }

            // ------------------------------------------------------------- FIRE
            case SHACKLES -> {
                LivingEntity t = target(p, num("shackles.range", 20));
                if (t == null) {
                    noTarget(p);
                    return false;
                }
                shackles.removeIf(s -> s.victim.equals(t.getUniqueId()));
                shackles.add(new Shackle(t.getUniqueId(), id, now + (long) (num("shackles.seconds", 20) * 1000), now + 1000));
                w.playSound(t.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1f, 0.7f);
                return true;
            }
            case FIRE_EXPLOSION -> {
                Vector dir = loc.getDirection().normalize();
                Fireball fb = p.launchProjectile(Fireball.class, dir.clone().multiply(1.6));
                fb.setDirection(dir);
                fb.setYield(0f);
                fb.setIsIncendiary(false);
                fb.getPersistentDataContainer().set(fireballKey, PersistentDataType.BYTE, (byte) 1);
                w.playSound(loc, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1f, 0.6f);
                Bukkit.getScheduler().runTaskTimer(this, task -> {
                    if (!fb.isValid() || fb.isDead()) {
                        task.cancel();
                        return;
                    }
                    fb.getWorld().spawnParticle(Particle.FLAME, fb.getLocation(), 8, 0.2, 0.2, 0.2, 0.02);
                    fb.getWorld().spawnParticle(Particle.LAVA, fb.getLocation(), 1, 0.1, 0.1, 0.1, 0);
                }, 0L, 1L);
                return true;
            }
            case FIRE_DOMAIN -> {
                createDomain(p, DomainType.FIRE, num("fire-domain.radius", 5), num("fire-domain.seconds", 20));
                return true;
            }

            // ------------------------------------------------------------- WATER
            case WATER_BLAST -> {
                LivingEntity t = target(p, num("water-blast.range", 25));
                if (t == null) {
                    noTarget(p);
                    return false;
                }
                Vector dir = t.getLocation().toVector().subtract(loc.toVector());
                double dist = dir.length();
                if (dist > 0.1) {
                    dir.normalize();
                    for (double d = 1; d < dist; d += 0.7) {
                        w.spawnParticle(Particle.SPLASH, loc.clone().add(0, 1.4, 0).add(dir.clone().multiply(d)), 8, 0.15, 0.15, 0.15, 0.1);
                    }
                }
                w.playSound(loc, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1.2f, 0.7f);
                abilityDamage(t, num("water-blast.damage", 8.0), p); // 4 hearts
                Vector flat = t.getLocation().toVector().subtract(loc.toVector()).setY(0);
                if (flat.lengthSquared() < 1.0E-4) flat = loc.getDirection().setY(0);
                flat.normalize().multiply(num("water-blast.knockback", 3.0)).setY(0.5);
                t.setVelocity(flat);
                return true;
            }
            case WATER_DOMAIN -> {
                createDomain(p, DomainType.WATER, num("water-domain.radius", 3), num("water-domain.seconds", 10));
                return true;
            }
            case WATER_BLADE -> {
                waterBladeUntil.put(id, now + (long) (num("water-blade.seconds", 30) * 1000));
                w.spawnParticle(Particle.SPLASH, loc.clone().add(0, 1, 0), 80, 0.5, 0.8, 0.5, 0.2);
                w.playSound(loc, Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.6f);
                p.sendActionBar(Component.text("Blade: your axe swings like a sword", NamedTextColor.AQUA));
                return true;
            }

            // ------------------------------------------------------------- ICE
            case FREEZE -> {
                LivingEntity t = target(p, num("freeze.range", 20));
                if (t == null) {
                    noTarget(p);
                    return false;
                }
                int ticks = (int) (num("freeze.seconds", 10) * 20);
                freezeEntity(t, ticks);
                t.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, ticks, 0, false, false, true));
                t.setFreezeTicks(t.getMaxFreezeTicks());
                t.getWorld().spawnParticle(Particle.SNOWFLAKE, t.getLocation().add(0, 1, 0), 60, 0.4, 0.8, 0.4, 0.03);
                w.playSound(t.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 0.6f);
                return true;
            }
            case FROZEN -> {
                createDomain(p, DomainType.FROZEN, num("frozen.radius", 30), num("frozen.seconds", 20));
                return true;
            }
            case METEOR -> {
                meteorArmedUntil.put(id, now + (long) (num("meteor.armed-seconds", 30) * 1000));
                w.spawnParticle(Particle.SNOWFLAKE, loc.clone().add(0, 1.5, 0), 40, 0.4, 0.4, 0.4, 0.02);
                w.playSound(loc, Sound.ENTITY_PLAYER_HURT_FREEZE, 1f, 1.2f);
                p.sendActionBar(Component.text("Meteor ready: your next arrow is coated", NamedTextColor.BLUE));
                return true;
            }

            // ------------------------------------------------------------- DARKNESS
            case SKULK -> {
                createDomain(p, DomainType.SKULK, num("skulk.radius", 5), num("skulk.seconds", 15));
                skulkUntil.put(id, now + (long) (num("skulk.seconds", 15) * 1000));
                return true;
            }
            case DRAIN -> {
                LivingEntity t = target(p, num("drain.range", 15));
                if (t == null) {
                    noTarget(p);
                    return false;
                }
                abilityDamage(t, num("drain.damage", 8.0), p); // 4 hearts
                int absorbTicks = (int) (num("drain.seconds", 10) * 20);
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, absorbTicks, 1, false, true, true)); // 4 hearts
                t.getWorld().spawnParticle(Particle.SQUID_INK, t.getLocation().add(0, 1, 0), 40, 0.3, 0.6, 0.3, 0.05);
                w.spawnParticle(Particle.HEART, loc.clone().add(0, 1.5, 0), 8, 0.4, 0.3, 0.4);
                w.playSound(loc, Sound.ENTITY_WITHER_HURT, 0.6f, 1.5f);
                return true;
            }
            case DARKSIDE -> {
                int slot = p.getInventory().firstEmpty();
                if (slot == -1) {
                    p.sendActionBar(Component.text("Free an inventory slot for the Skulk Sword", NamedTextColor.RED));
                    return false;
                }
                p.getInventory().setItem(slot, createSkulkSword());
                if (slot < 9) p.getInventory().setHeldItemSlot(slot);
                darksideUntil.put(id, now + (long) (num("darkside.seconds", 60) * 1000));
                darksideNextBoom.put(id, now + (long) (num("darkside.sonic-interval-seconds", 5) * 1000));
                w.spawnParticle(Particle.SCULK_SOUL, loc.clone().add(0, 1, 0), 40, 0.5, 0.8, 0.5, 0.05);
                w.playSound(loc, Sound.ENTITY_WARDEN_EMERGE, 0.8f, 1.4f);
                p.sendActionBar(Component.text("The Skulk Sword is yours", NamedTextColor.DARK_AQUA));
                return true;
            }
        }
        return false;
    }

    // =====================================================================
    //  Timed ability effects (domains, shackles, stuns, blade, strength, Darkside)
    // =====================================================================

    private void abilityTick() {
        long now = System.currentTimeMillis();
        if (auraParticles && (++auraCounter % 3 == 0)) auraPuff();

        // ---- domains ----
        Iterator<Domain> di = domains.iterator();
        while (di.hasNext()) {
            Domain d = di.next();
            Player owner = Bukkit.getPlayer(d.owner);
            if (now >= d.end || owner == null || !owner.isOnline()) {
                di.remove();
                continue;
            }
            tickDomain(d, owner);
        }

        // ---- shackles ----
        Iterator<Shackle> si = shackles.iterator();
        while (si.hasNext()) {
            Shackle s = si.next();
            Entity victim = Bukkit.getEntity(s.victim);
            Player owner = Bukkit.getPlayer(s.owner);
            if (now >= s.end || owner == null || !(victim instanceof LivingEntity lv) || !lv.isValid() || lv.isDead()) {
                si.remove();
                continue;
            }
            applyStun(lv, 20);
            if (lv instanceof Player vp) frozenUntil.put(vp.getUniqueId(), now + 600);
            ring(lv.getLocation(), 1.3, Particle.FLAME, 16, 0.2);
            ring(lv.getLocation(), 1.3, Particle.FLAME, 16, 1.0);
            ring(lv.getLocation(), 1.3, Particle.FLAME, 16, 1.8);
            if (now >= s.nextDamage) {
                s.nextDamage += 1000;
                abilityDamage(lv, num("shackles.damage-per-second", 1.0), owner); // ignores fire resistance
            }
        }

        // ---- expired stuns ----
        frozenUntil.values().removeIf(until -> until <= now);

        // ---- Strength expiry ----
        for (Map.Entry<UUID, Long> en : new ArrayList<>(strengthUntil.entrySet())) {
            if (now < en.getValue()) continue;
            strengthUntil.remove(en.getKey());
            Player pl = Bukkit.getPlayer(en.getKey());
            if (pl != null) {
                removeMod(pl, Attribute.ARMOR_TOUGHNESS, modStrengthTough);
                removeMod(pl, Attribute.KNOCKBACK_RESISTANCE, modStrengthKb);
                pl.sendActionBar(Component.text("Strength faded", NamedTextColor.GRAY));
            }
        }

        // ---- Thunder Blade / Skulk / Meteor expiry bookkeeping ----
        thunderBladeUntil.values().removeIf(until -> until <= now);
        skulkUntil.values().removeIf(until -> until <= now);
        meteorArmedUntil.values().removeIf(until -> until <= now);

        // ---- Water Blade: axe attacks as fast as a sword ----
        for (Map.Entry<UUID, Long> en : new ArrayList<>(waterBladeUntil.entrySet())) {
            Player pl = Bukkit.getPlayer(en.getKey());
            if (pl == null) {
                waterBladeUntil.remove(en.getKey());
                continue;
            }
            if (now >= en.getValue()) {
                waterBladeUntil.remove(en.getKey());
                removeMod(pl, Attribute.ATTACK_SPEED, modBladeSpeed);
                pl.sendActionBar(Component.text("Blade faded", NamedTextColor.GRAY));
                continue;
            }
            if (pl.getInventory().getItemInMainHand().getType().name().endsWith("_AXE")) {
                setMod(pl, Attribute.ATTACK_SPEED, modBladeSpeed, num("water-blade.attack-speed-bonus", 0.6),
                        AttributeModifier.Operation.ADD_NUMBER);
            } else {
                removeMod(pl, Attribute.ATTACK_SPEED, modBladeSpeed);
            }
        }

        // ---- Darkside: Skulk Sword fires a sonic boom on an interval ----
        for (Map.Entry<UUID, Long> en : new ArrayList<>(darksideUntil.entrySet())) {
            Player pl = Bukkit.getPlayer(en.getKey());
            if (pl == null || pl.isDead()) {
                darksideUntil.remove(en.getKey());
                darksideNextBoom.remove(en.getKey());
                continue;
            }
            if (now >= en.getValue()) {
                darksideUntil.remove(en.getKey());
                darksideNextBoom.remove(en.getKey());
                removeSkulkSword(pl);
                pl.sendActionBar(Component.text("The Skulk Sword crumbles", NamedTextColor.GRAY));
                continue;
            }
            long next = darksideNextBoom.getOrDefault(en.getKey(), now);
            if (now >= next) {
                darksideNextBoom.put(en.getKey(), now + (long) (num("darkside.sonic-interval-seconds", 5) * 1000));
                sonicBoom(pl);
            }
        }
    }

    private void tickDomain(Domain d, Player owner) {
        Location c = d.center;
        World w = c.getWorld();
        if (w == null) return;
        Particle particle = switch (d.type) {
            case FIRE -> Particle.FLAME;
            case WATER -> Particle.SPLASH;
            case FROZEN -> Particle.SNOWFLAKE;
            case SKULK -> Particle.SCULK_SOUL;
        };
        if (d.radius <= 12) {
            ring(c, d.radius, particle, 36, 0.2);
            ring(c, d.radius, particle, 36, 1.4);
        } else {
            // very large domains: sparse particles around the caster only
            w.spawnParticle(particle, owner.getLocation().add(0, 1, 0), 40, 6, 2, 6, 0.02);
        }
        for (LivingEntity t : nearbyLiving(c, d.radius, owner)) {
            switch (d.type) {
                case FIRE -> {
                    clearEffects(t);
                    t.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, false, false, true));
                    t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1, false, false, true));
                }
                case WATER -> {
                    freezeEntity(t, 15);
                    w.spawnParticle(Particle.SPLASH, t.getLocation().add(0, 1, 0), 6, 0.3, 0.5, 0.3, 0.05);
                }
                case FROZEN -> {
                    clearEffects(t);
                    t.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, false, false, true));
                }
                case SKULK -> t.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, false, false, true));
            }
        }
    }

    private void createDomain(Player p, DomainType type, double radius, double seconds) {
        Location c = p.getLocation().clone();
        long end = System.currentTimeMillis() + (long) (seconds * 1000);
        domains.add(new Domain(p.getUniqueId(), c, radius, end, type));
        World w = c.getWorld();
        if (w == null) return;
        switch (type) {
            case FIRE -> w.playSound(c, Sound.ITEM_FIRECHARGE_USE, 1.2f, 0.6f);
            case WATER -> w.playSound(c, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1.2f, 0.6f);
            case FROZEN -> w.playSound(c, Sound.BLOCK_GLASS_BREAK, 1.2f, 0.5f);
            case SKULK -> w.playSound(c, Sound.ENTITY_WARDEN_EMERGE, 1f, 1.2f);
        }
    }

    private void clearEffects(LivingEntity t) {
        for (PotionEffect pe : new ArrayList<>(t.getActivePotionEffects())) {
            t.removePotionEffect(pe.getType());
        }
    }

    /** Stuns an entity: it cannot move, jump (potion effects) and, for players, cannot attack or use abilities. */
    private void freezeEntity(LivingEntity t, int ticks) {
        applyStun(t, ticks);
        if (t instanceof Player pl) {
            frozenUntil.put(pl.getUniqueId(), System.currentTimeMillis() + ticks * 50L);
        }
    }

    private void applyStun(LivingEntity t, int ticks) {
        t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, 6, false, false, true));
        t.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, ticks, 128, false, false, false));
    }

    private void ring(Location c, double r, Particle particle, int points, double yOffset) {
        World w = c.getWorld();
        if (w == null) return;
        for (int i = 0; i < points; i++) {
            double ang = 2 * Math.PI * i / points;
            w.spawnParticle(particle, c.getX() + Math.cos(ang) * r, c.getY() + yOffset, c.getZ() + Math.sin(ang) * r,
                    1, 0, 0, 0, 0);
        }
    }

    // =====================================================================
    //  Ground Burst pit
    // =====================================================================

    private void createPit(Location at, int depth, int restoreTicks) {
        World w = at.getWorld();
        if (w == null) return;
        int y0 = at.getBlockY() - 1; // block under the target's feet
        Pit pit = new Pit(w, at.clone(), at.getBlockX() - 1, at.getBlockX() + 1, at.getBlockZ() - 1, at.getBlockZ() + 1, y0);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = 0; dy < depth; dy++) {
                    Block b = w.getBlockAt(at.getBlockX() + dx, y0 - dy, at.getBlockZ() + dz);
                    Material m = b.getType();
                    if (m.isAir() || m.getHardness() < 0 || b.isLiquid() || b.getState() instanceof TileState) continue;
                    pit.blocks.add(b);
                    pit.data.add(b.getBlockData());
                    b.setType(Material.AIR, false);
                }
            }
        }
        pits.add(pit);
        w.spawnParticle(Particle.BLOCK, at, 120, 1.5, 0.3, 1.5, Material.DIRT.createBlockData());
        Bukkit.getScheduler().runTaskLater(this, () -> restorePit(pit), restoreTicks);
    }

    private void restorePit(Pit pit) {
        if (!pits.remove(pit)) return; // already restored
        // lift anything still inside back to the surface so nobody is trapped in rock
        for (Entity en : pit.world.getNearbyEntities(pit.center, 4, depthOf(pit) + 4, 4)) {
            Location l = en.getLocation();
            if (l.getBlockX() >= pit.minX && l.getBlockX() <= pit.maxX
                    && l.getBlockZ() >= pit.minZ && l.getBlockZ() <= pit.maxZ
                    && l.getBlockY() <= pit.topY) {
                l.setY(pit.topY + 1.2);
                en.teleport(l);
            }
        }
        for (int i = 0; i < pit.blocks.size(); i++) {
            pit.blocks.get(i).setBlockData(pit.data.get(i), false);
        }
    }

    private int depthOf(Pit pit) {
        int lowest = pit.topY;
        for (Block b : pit.blocks) lowest = Math.min(lowest, b.getY());
        return pit.topY - lowest + 1;
    }

    // =====================================================================
    //  Skulk Sword (Darkside)
    // =====================================================================

    private ItemStack createSkulkSword() {
        ItemStack item = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Skulk Sword", NamedTextColor.DARK_AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Fires a sonic boom every few seconds", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(skulkSwordKey, PersistentDataType.BYTE, (byte) 1);
        if (iconsEnabled && menuItemModels) {
            NamespacedKey model = NamespacedKey.fromString("elementssmp:skulk_sword");
            if (model != null) meta.setItemModel(model);
        }
        item.setItemMeta(meta);
        return item;
    }

    private boolean isSkulkSword(ItemStack item) {
        return item != null && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(skulkSwordKey, PersistentDataType.BYTE);
    }

    private void removeSkulkSword(Player p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            if (isSkulkSword(inv.getItem(i))) inv.setItem(i, null);
        }
    }

    private void sonicBoom(Player p) {
        Location eye = p.getEyeLocation();
        LivingEntity best = null;
        double bestSq = Double.MAX_VALUE;
        double range = num("darkside.sonic-range", 15);
        for (LivingEntity t : nearbyLiving(p.getLocation(), range, p)) {
            double dsq = t.getLocation().distanceSquared(p.getLocation());
            if (dsq < bestSq) {
                bestSq = dsq;
                best = t;
            }
        }
        Vector dir = best != null
                ? best.getEyeLocation().toVector().subtract(eye.toVector()).normalize()
                : eye.getDirection().normalize();
        double len = best != null ? Math.sqrt(bestSq) + 1 : range;
        World w = p.getWorld();
        for (double d = 1; d < len; d += 1.0) {
            w.spawnParticle(Particle.SONIC_BOOM, eye.clone().add(dir.clone().multiply(d)), 1, 0, 0, 0, 0);
        }
        w.playSound(eye, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 1f);
        if (best != null) {
            abilityDamage(best, num("darkside.sonic-damage", 10.0), p);
            best.setVelocity(best.getVelocity().add(dir.clone().multiply(1.1).setY(0.3)));
        }
    }

    // =====================================================================
    //  Fire passive: faster movement in lava
    // =====================================================================

    private void tickFire(Player p) {
        if (p.getLocation().getBlock().getType() != Material.LAVA
                && p.getEyeLocation().getBlock().getType() != Material.LAVA) return;
        Vector v = p.getVelocity();
        double h = Math.sqrt(v.getX() * v.getX() + v.getZ() * v.getZ());
        if (h < 0.01 || h > 0.45) return;
        double f = 1.35;
        p.setVelocity(new Vector(v.getX() * f, v.getY(), v.getZ() * f));
    }

    // =====================================================================
    //  Ability cleanup and combat hooks
    // =====================================================================

    private void cleanupAbilities(Player p) {
        UUID id = p.getUniqueId();
        strengthUntil.remove(id);
        waterBladeUntil.remove(id);
        thunderBladeUntil.remove(id);
        skulkUntil.remove(id);
        darksideUntil.remove(id);
        darksideNextBoom.remove(id);
        meteorArmedUntil.remove(id);
        frozenUntil.remove(id);
        removeMod(p, Attribute.ARMOR_TOUGHNESS, modStrengthTough);
        removeMod(p, Attribute.KNOCKBACK_RESISTANCE, modStrengthKb);
        removeMod(p, Attribute.ATTACK_SPEED, modBladeSpeed);
        removeSkulkSword(p);
        domains.removeIf(d -> d.owner.equals(id));
        shackles.removeIf(s -> s.owner.equals(id));
    }

    /** Stunned players cannot attack; Thunder Blade, Skulk and the special projectiles adjust damage. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAbilityDamage(EntityDamageEvent e) {
        if (!(e instanceof EntityDamageByEntityEvent be)) return;
        Entity damager = be.getDamager();
        long now = System.currentTimeMillis();

        if (damager instanceof Fireball fb
                && fb.getPersistentDataContainer().has(fireballKey, PersistentDataType.BYTE)) {
            Location hit = e.getEntity().getLocation().add(0, 1, 0);
            e.getEntity().getWorld().spawnParticle(Particle.EXPLOSION, hit, 1);
            e.getEntity().getWorld().spawnParticle(Particle.FLAME, hit, 80, 0.6, 0.6, 0.6, 0.15);
            e.setDamage(num("fire-explosion.damage", 16.0)); // 8 hearts
            return;
        }
        if (damager instanceof Arrow arrow
                && arrow.getPersistentDataContainer().has(meteorArrowKey, PersistentDataType.BYTE)) {
            e.setDamage(num("meteor.damage", 5.0)); // 2.5 hearts
            e.getEntity().getWorld().spawnParticle(Particle.DUST, e.getEntity().getLocation().add(0, 1, 0), 40,
                    0.4, 0.6, 0.4, 0, new Particle.DustOptions(Color.fromRGB(10, 40, 160), 1.8f));
        }

        Player attacker = null;
        if (damager instanceof Player pl) attacker = pl;
        else if (damager instanceof Projectile pr && pr.getShooter() instanceof Player sp) attacker = sp;
        if (attacker == null) return;

        UUID id = attacker.getUniqueId();
        if (frozenUntil.getOrDefault(id, 0L) > now) {
            e.setCancelled(true);
            return;
        }
        if (inAbilityDamage) return;
        double mult = 1.0;
        if (skulkUntil.getOrDefault(id, 0L) > now) mult *= 1.5;
        if (damager instanceof Player && be.isCritical() && thunderBladeUntil.getOrDefault(id, 0L) > now) {
            mult *= 1.5;
            e.getEntity().getWorld().strikeLightningEffect(e.getEntity().getLocation());
        }
        if (mult != 1.0) e.setDamage(e.getDamage() * mult);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onFrozenInteract(PlayerInteractEvent e) {
        if (frozenUntil.getOrDefault(e.getPlayer().getUniqueId(), 0L) > System.currentTimeMillis()) {
            e.setCancelled(true);
        }
    }

    /** Meteor: the next arrow after using the ability is coated dark blue and hits for 2.5 hearts. */
    @EventHandler
    public void onShoot(EntityShootBowEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        if (frozenUntil.getOrDefault(id, 0L) > now) {
            e.setCancelled(true);
            return;
        }
        if (meteorArmedUntil.getOrDefault(id, 0L) <= now) return;
        if (!(e.getProjectile() instanceof Arrow arrow)) return;
        meteorArmedUntil.remove(id);
        arrow.getPersistentDataContainer().set(meteorArrowKey, PersistentDataType.BYTE, (byte) 1);
        arrow.setColor(Color.fromRGB(10, 30, 140));
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            if (!arrow.isValid() || arrow.isDead() || arrow.isInBlock() || arrow.isOnGround()) {
                task.cancel();
                return;
            }
            arrow.getWorld().spawnParticle(Particle.DUST, arrow.getLocation(), 6, 0.05, 0.05, 0.05, 0,
                    new Particle.DustOptions(Color.fromRGB(10, 40, 160), 1.4f));
        }, 0L, 1L);
    }

    /** Keeps the Skulk Sword out of chests and other containers. */
    @EventHandler(ignoreCancelled = true)
    public void onSwordClick(InventoryClickEvent e) {
        InventoryType top = e.getView().getTopInventory().getType();
        if (top == InventoryType.CRAFTING || top == InventoryType.PLAYER) return;
        if (isSkulkSword(e.getCurrentItem()) || isSkulkSword(e.getCursor())) e.setCancelled(true);
    }

    // ---- particle effects ----

    private Particle mainParticle(Element e) {
        return switch (e) {
            case EARTH -> Particle.HAPPY_VILLAGER;
            case WIND -> Particle.CLOUD;
            case LIGHTNING -> Particle.ELECTRIC_SPARK;
            case FIRE -> Particle.FLAME;
            case WATER -> Particle.SPLASH;
            case DARKNESS -> Particle.SCULK_SOUL;
            case ICE -> Particle.SNOWFLAKE;
        };
    }

    private Particle altParticle(Element e) {
        return switch (e) {
            case EARTH -> Particle.COMPOSTER;
            case WIND -> Particle.END_ROD;
            case LIGHTNING -> Particle.FIREWORK;
            case FIRE -> Particle.LAVA;
            case WATER -> Particle.DRIPPING_WATER;
            case DARKNESS -> Particle.PORTAL;
            case ICE -> Particle.ITEM_SNOWBALL;
        };
    }

    /** Element-coloured effect every time an ability fires: a rising spiral, a ground ring and a burst. */
    private void castEffect(Player p, Element el) {
        World w = p.getWorld();
        Particle main = mainParticle(el);
        Particle alt = altParticle(el);
        ring(p.getLocation(), 1.6, main, 28, 0.15);
        ring(p.getLocation(), 2.6, alt, 36, 0.15);
        w.spawnParticle(alt, p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(0.8)), 30, 0.3, 0.3, 0.3, 0.08);
        int[] tick = {0};
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            if (!p.isOnline() || p.isDead() || tick[0] > 14) {
                task.cancel();
                return;
            }
            Location base = p.getLocation();
            double y = tick[0] * 0.14;
            for (int i = 0; i < 3; i++) {
                double ang = tick[0] * 0.6 + i * 2.094;
                w.spawnParticle(main, base.getX() + Math.cos(ang) * 0.9, base.getY() + y, base.getZ() + Math.sin(ang) * 0.9,
                        2, 0.04, 0.04, 0.04, 0.01);
            }
            tick[0]++;
        }, 0L, 1L);
    }

    /** A few element particles around every player that has an element, so they are easy to tell apart. */
    private void auraPuff() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isDead() || p.isInvisible() || p.getGameMode() == GameMode.SPECTATOR) continue;
            Element el = elementCache.get(p.getUniqueId());
            if (el == null || disabledWorlds.contains(p.getWorld().getName())) continue;
            Location l = p.getLocation();
            p.getWorld().spawnParticle(mainParticle(el),
                    l.getX() + (r.nextDouble() - 0.5) * 0.8, l.getY() + r.nextDouble() * 1.9, l.getZ() + (r.nextDouble() - 0.5) * 0.8,
                    1, 0, 0, 0, 0.01);
        }
    }

    // ---- ability helpers ----

    private LivingEntity target(Player p, double range) {
        RayTraceResult r = p.getWorld().rayTraceEntities(p.getEyeLocation(), p.getEyeLocation().getDirection(),
                range, 0.6, en -> en instanceof LivingEntity && !en.equals(p) && !(en instanceof ArmorStand)
                        && !(en instanceof Player pl && pl.getGameMode() == GameMode.SPECTATOR));
        if (r != null && r.getHitEntity() instanceof LivingEntity le) return le;
        return null;
    }

    private List<LivingEntity> nearbyLiving(Location c, double r, Entity self) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity en : nearbyAll(c, r, self)) {
            if (en instanceof LivingEntity le && !(en instanceof ArmorStand)) out.add(le);
        }
        return out;
    }

    private List<Entity> nearbyAll(Location c, double r, Entity self) {
        List<Entity> out = new ArrayList<>();
        for (Entity en : c.getWorld().getNearbyEntities(c, r, r, r)) {
            if (en.equals(self)) continue;
            if (en instanceof Player pl && pl.getGameMode() == GameMode.SPECTATOR) continue;
            if (en.getLocation().distanceSquared(c) > r * r) continue;
            out.add(en);
        }
        return out;
    }

    private void push(Entity from, Entity en, double strength, double up) {
        Vector v = en.getLocation().toVector().subtract(from.getLocation().toVector());
        v.setY(0);
        if (v.lengthSquared() < 1.0E-4) {
            v = new Vector(ThreadLocalRandom.current().nextDouble() - 0.5, 0, ThreadLocalRandom.current().nextDouble() - 0.5);
        }
        v.normalize().multiply(strength).setY(up);
        en.setVelocity(v);
    }

    private void abilityDamage(LivingEntity target, double amount, Player source) {
        inAbilityDamage = true;
        try {
            target.damage(amount, source);
        } finally {
            inAbilityDamage = false;
        }
    }

    // =====================================================================
    //  Commands
    // =====================================================================

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("ability")) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage("Players only.");
                return true;
            }
            Element el = getElement(p);
            if (el == null) return true;
            Ability[] list = el.selectable();
            int idx;
            if (args.length == 0) {
                idx = Math.floorMod(selected.getOrDefault(p.getUniqueId(), 0), list.length);
            } else {
                try {
                    idx = Integer.parseInt(args[0]) - 1;
                } catch (NumberFormatException ex) {
                    p.sendMessage(Component.text("Usage: /ability <1-" + list.length + ">", NamedTextColor.RED));
                    return true;
                }
                if (idx < 0 || idx >= list.length) {
                    p.sendMessage(Component.text("Pick a number from 1 to " + list.length, NamedTextColor.RED));
                    return true;
                }
            }
            use(p, list[idx]);
            return true;
        }

        // /element
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Players only.");
                    return true;
                }
                Element el = getElement(p);
                if (el == null) {
                    p.sendMessage(Component.text("You don't have an element.", NamedTextColor.RED));
                    return true;
                }
                p.sendMessage(Component.text("Your element: ", NamedTextColor.GRAY).append(elementLabel(el)));
                p.sendMessage(Component.text("Use /element info for your abilities.", NamedTextColor.DARK_GRAY));
            }
            case "info" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Players only.");
                    return true;
                }
                Element el = getElement(p);
                if (el == null) {
                    p.sendMessage(Component.text("You don't have an element.", NamedTextColor.RED));
                    return true;
                }
                p.sendMessage(Component.text("Your element: ", NamedTextColor.GRAY).append(elementLabel(el)));
                int n = 1;
                for (Ability a : el.selectable()) {
                    p.sendMessage(Component.text(" " + n++ + ". " + a.display() + " (" + a.cooldown() + "s) - " + a.input().label(), NamedTextColor.GRAY));
                }
                sendKeyHelp(p);
                p.sendMessage(Component.text(globalCooldownSeconds + "s wait between any two abilities.", NamedTextColor.DARK_GRAY));
            }
            case "list" -> {
                for (Element el : Element.values()) {
                    StringBuilder sb = new StringBuilder();
                    for (Ability a : el.abilities()) {
                        if (sb.length() > 0) sb.append(", ");
                        sb.append(a.display());
                    }
                    sender.sendMessage(elementLabel(el).append(Component.text(": " + sb, NamedTextColor.GRAY)));
                }
            }
            case "debug" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Players only.");
                    return true;
                }
                boolean on = debugPlayers.add(p.getUniqueId());
                if (!on) debugPlayers.remove(p.getUniqueId());
                p.sendMessage(Component.text("ElementsSMP build " + BUILD + ": debug " + (on ? "ON" : "OFF"), NamedTextColor.GOLD));
                p.sendMessage(Component.text("element=" + getElement(p) + " | F-swap=" + keyG + ", Q-drop=" + dropKeyR
                        + ", Shift+F-third=" + shiftSwapThird + ", slot9=" + slot9C + " | global wait="
                        + globalCooldownSeconds + "s | disabled worlds=" + disabledWorlds, NamedTextColor.GRAY));
                if (on) p.sendMessage(Component.text("Now press your ability keys; every key press is reported here.", NamedTextColor.GRAY));
            }
            case "menu" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Players only.");
                    return true;
                }
                openMenu(p);
            }
            case "cooldowns" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Players only.");
                    return true;
                }
                Element el = getElement(p);
                if (el == null) {
                    p.sendMessage(Component.text("You don't have an element.", NamedTextColor.RED));
                    return true;
                }
                long now = System.currentTimeMillis();
                Map<Ability, Long> cd = cooldowns.getOrDefault(p.getUniqueId(), Map.of());
                p.sendMessage(Component.text("Ability cooldowns:", NamedTextColor.GRAY));
                for (Ability a : el.abilities()) {
                    long until = cd.getOrDefault(a, 0L);
                    Component state = until <= now
                            ? Component.text("ready", NamedTextColor.GREEN)
                            : Component.text(((until - now + 999) / 1000) + "s", NamedTextColor.RED);
                    p.sendMessage(Component.text(" " + a.display() + ": ", NamedTextColor.GRAY).append(state));
                }
            }
            case "stats" -> {
                Map<Element, Integer> online = new EnumMap<>(Element.class);
                for (Player pl : Bukkit.getOnlinePlayers()) {
                    Element pe = getElement(pl);
                    if (pe != null) online.merge(pe, 1, Integer::sum);
                }
                sender.sendMessage(Component.text("Elemental statistics", NamedTextColor.GOLD, TextDecoration.BOLD));
                sender.sendMessage(Component.text("Element: online now / times given / abilities used / kills", NamedTextColor.DARK_GRAY));
                for (Element el : Element.values()) {
                    sender.sendMessage(elementLabel(el).append(Component.text(
                            ": " + online.getOrDefault(el, 0) + " / " + statAssigned.getOrDefault(el, 0)
                                    + " / " + statUses.getOrDefault(el, 0) + " / " + statKills.getOrDefault(el, 0), NamedTextColor.GRAY)));
                }
                if (sender instanceof Player p) {
                    int[] mine = statPlayer.getOrDefault(p.getUniqueId(), new int[2]);
                    sender.sendMessage(Component.text("You: " + mine[0] + " elements received, "
                            + mine[1] + " abilities used", NamedTextColor.GRAY));
                }
            }
            case "give" -> {
                if (!sender.hasPermission("elementssmp.admin")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage(Component.text("Usage: /element give <player>", NamedTextColor.RED));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) {
                    if (!queueOffline(sender, args[1], "GIVE")) {
                        sender.sendMessage(Component.text("Unknown player.", NamedTextColor.RED));
                    }
                    return true;
                }
                Element next = randomElement(getElement(t));
                setElement(t, next);
                sender.sendMessage(Component.text(t.getName() + " was given ", NamedTextColor.GREEN).append(elementLabel(next)));
                t.sendMessage(Component.text("You were given the ", NamedTextColor.GRAY)
                        .append(elementLabel(next)).append(Component.text(" element!", NamedTextColor.GRAY)));
            }
            case "set" -> {
                if (!sender.hasPermission("elementssmp.admin")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage(Component.text("Usage: /element set <player> <element>", NamedTextColor.RED));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                Element el = Element.parse(args[2]);
                if (el == null) {
                    sender.sendMessage(Component.text("Unknown element.", NamedTextColor.RED));
                    return true;
                }
                if (t == null) {
                    if (!queueOffline(sender, args[1], "SET:" + el.name())) {
                        sender.sendMessage(Component.text("Unknown player.", NamedTextColor.RED));
                    }
                    return true;
                }
                setElement(t, el);
                sender.sendMessage(Component.text(t.getName() + " is now ", NamedTextColor.GREEN).append(elementLabel(el)));
                t.sendMessage(Component.text("Your element is now ", NamedTextColor.GRAY).append(elementLabel(el)));
            }
            case "reset" -> {
                if (!sender.hasPermission("elementssmp.admin")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage(Component.text("Usage: /element reset <player>", NamedTextColor.RED));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) {
                    if (!queueOffline(sender, args[1], "RESET")) {
                        sender.sendMessage(Component.text("Unknown player.", NamedTextColor.RED));
                    }
                    return true;
                }
                clearElement(t);
                sender.sendMessage(Component.text(t.getName() + "'s element was reset.", NamedTextColor.GREEN));
                if (resetAssignsRandom) {
                    Element fresh = randomElement(null);
                    setElement(t, fresh);
                    t.sendMessage(Component.text("Your element was reset. You now have ", NamedTextColor.GRAY)
                            .append(elementLabel(fresh)));
                } else {
                    t.sendMessage(Component.text("Your element was reset.", NamedTextColor.GRAY));
                }
            }
            case "reload" -> {
                if (!sender.hasPermission("elementssmp.admin")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                loadSettings();
                for (Player pl : Bukkit.getOnlinePlayers()) {
                    updateDisplay(pl);
                    sendPack(pl);
                }
                sender.sendMessage(Component.text("ElementsSMP configuration reloaded.", NamedTextColor.GREEN));
            }
            case "book" -> {
                if (!sender.hasPermission("elementssmp.admin")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                Player t = args.length >= 2 ? Bukkit.getPlayerExact(args[1])
                        : (sender instanceof Player sp ? sp : null);
                if (t == null) {
                    sender.sendMessage(Component.text("Usage: /element book [player]", NamedTextColor.RED));
                    return true;
                }
                t.getInventory().addItem(createBook()).values()
                        .forEach(left -> t.getWorld().dropItemNaturally(t.getLocation(), left));
                sender.sendMessage(Component.text("Gave an Element Reroll Book to " + t.getName(), NamedTextColor.GREEN));
            }
            default -> sender.sendMessage(Component.text(
                    "Usage: /element [info|list|menu|cooldowns|stats|debug|give|set|reset|reload|book]", NamedTextColor.RED));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (cmd.getName().equalsIgnoreCase("ability")) {
            if (args.length == 1 && sender instanceof Player p) {
                Element el = getElement(p);
                if (el != null) for (int i = 1; i <= el.selectable().length; i++) out.add(String.valueOf(i));
            }
            return out;
        }
        boolean admin = sender.hasPermission("elementssmp.admin");
        if (args.length == 1) {
            out.addAll(List.of("info", "list", "menu", "cooldowns", "stats", "debug"));
            if (admin) out.addAll(List.of("give", "set", "reset", "reload", "book"));
        } else if (args.length == 2 && admin
                && List.of("give", "set", "reset", "book").contains(args[0].toLowerCase(Locale.ROOT))) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (args.length == 3 && admin && args[0].equalsIgnoreCase("set")) {
            for (Element el : Element.values()) out.add(el.name().toLowerCase(Locale.ROOT));
        }
        String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(prefix));
        return out;
    }
}
