# ElementsSMP (Paper 26.2, Java Edition)

Build (needs JDK 25 and internet access to repo.papermc.io):

    mvn clean package

The jar is created at target/ElementsSMP-1.0.0.jar. Drop it in your server's plugins/ folder.
A GitHub Actions workflow (.github/workflows/build.yml) builds it for you online.

## Controls
- Abilities are called R (first), G (second) and C (third). After using ANY ability a player must wait
  **10 seconds** before using another one (`global-cooldown-seconds`); each ability also has its own cooldown.
- Minecraft has no ability keys, so these existing keys work with no setup:
  - **Q** = first ability (Shift+Q still drops items)
  - **F** = second ability
  - **Shift+F** = third ability
- To use the letters instead, players open Options > Controls and set "Drop Selected Item" to **R** and
  "Swap Item With Offhand" to **G**. Then R, G and Shift+G do the same. For **C**, set "Hotbar Slot 9" to C and
  turn on `keys.slot9-c` in config.yml.
- Anyone can always use /ability 1, /ability 2, /ability 3.
- A companion client mod can send R, G or C on the plugin channel `elementssmp:input`.

## Abilities (cooldowns in seconds)
| Element | R | G | C |
|---|---|---|---|
| Earth | Quake (60): stuns nearby players, slowness for 30s | Strength (300): diamond armor acts like netherite for 90s | Ground Burst (180): ground splits, an enemy falls inside |
| Wind | Wind Dash (50) | Air Gush (90): launches an enemy to the height limit | Storm Vortex (180): 5-block gust that throws everything away |
| Lightning | Lightning Strike (45, assumed): 5 hearts | Thunder Blade (200): 40s, critical hits call lightning, x1.5 damage | Dash (30) |
| Fire | Shackles (100): ring of fire binds and burns an enemy for 20s | Fire Explosion (300): fireball, 8 hearts | Domain (150): radius 5, 20s, blinds, clears effects, slows |
| Water | Blast (80): 4 hearts and knockback | Domain (300): radius 3, 10s, enemies frozen | Blade (80): axe attacks like a sword for 30s |
| Ice | Freeze (60): blind and stun for 10s | Frozen (300, assumed): radius 30, 20s, blinds, clears effects | Meteor (90, assumed): next arrow coated, 2.5 hearts |
| Darkness | Skulk (100): radius 5 domain, blinds, your attacks x1.5, 15s | Drain (150): take 4 hearts, gain 4 hearts for 10s | Darkside (150): Skulk Sword for 60s, sonic boom every 5s |

Cooldowns marked "assumed" were missing from the design document; change them in config.yml.
All numbers (damage, radius, durations) are in config.yml under `abilities`.

How a few of them work:
- Stun / frozen = cannot move, jump, attack, shoot or use abilities.
- Strength: each diamond armor piece worn gives +1 armor toughness and +0.1 knockback resistance
  (the exact difference between diamond and netherite). Your items are never swapped.
- Ground Burst: a 3x3 pit, 4 deep, restored after 8 seconds (anyone inside is lifted out first).
  Chests, furnaces and other containers are never touched.
- Skulk Sword: bound to you, can't be dropped, removed when the 60s end, on death or logout.

## Passives
Earth: damage reduction, knockback resistance, faster mining, explosion resistance.
Wind: increased movement speed, reduced fall damage. Lightning: combat speed boost, extra PvP damage in
rain/thunderstorms. Fire: fire, lava and campfire immunity, extra Fire Aspect damage, faster in lava.
Water: water breathing, faster swimming, extra damage in water.
Darkness: night vision, extra night-time damage and resistance.
Ice: faster on snow, freezes water underfoot, powder snow immunity, freezes enemies on critical hits.

## Random elements
- Every login gives a random element (`random-on-join`, `avoid-repeat`).
- `rejoin-lock-minutes` (default 30): rejoin within that time and you keep your element.
- Element Reroll Book (custom item, normal books never work). Right-click to reroll; always a new element.
  Shaped recipe (W = Nether Wart, T = Totem of Undying, S = Nether Star):

      W T W
      T S T
      W T W

## Commands
| Command | Function | Permission |
|---|---|---|
| /element | Check your element | everyone |
| /element info | Your abilities and keys | everyone |
| /element list | All elements and abilities | everyone |
| /element menu | Open the element menu | everyone |
| /element cooldowns | Your ability cooldowns | everyone |
| /element stats | Online / times given / abilities used / kills | everyone |
| /element give <player> | Random element for a player | elementssmp.admin |
| /element set <player> <element> | Set a player's element | elementssmp.admin |
| /element reset <player> | Reset a player's element | elementssmp.admin |
| /element reload | Reload config.yml | elementssmp.admin |
| /element book [player] | Give an Element Reroll Book | elementssmp.admin |
| /ability <1-3> | Use ability 1 (R), 2 (G) or 3 (C) | everyone |

give / set / reset also work on offline players who have joined before (applied on next login).

## Element icons
Each player's element icon floats above their head (and shows before their name in chat) for players
who have the icon resource pack loaded. The pack is bundled inside the plugin jar. On startup it is
copied to plugins/ElementsSMP/ElementsSMP-Icons-ResourcePack.zip, its SHA-1 is computed automatically,
and every player who joins is offered it.
Game clients download the pack from a web address, so the zip must be reachable at a link: upload the
copied zip to a public place (e.g. a public GitHub repo) and set resource-pack.url in config.yml.
Hosts that open a second port (not Aternos) can switch on resource-pack.self-host instead.
The pack also contains the Skulk Sword model and element item models (elementssmp:earth ... :ice).
